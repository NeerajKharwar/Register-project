package com.coderavi.register;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class adduserActivity extends AppCompatActivity {
    EditText etName , etEmail, etPhone;
    Button submit;
    FirebaseAuth fAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_captchapage);
        
        etName = findViewById(R.id.et_name);
        etEmail = findViewById(R.id.et_email);
        etPhone = findViewById(R.id.et_phone);
        submit = findViewById(R.id.button);

        fAuth = FirebaseAuth.getInstance();

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = etEmail.getText().toString().trim();
                String name = etName.getText().toString().trim();

                if(TextUtils.isEmpty(email)) {
                    etEmail.setError("Email is required");
                    return;
                }
                if(TextUtils.isEmpty(name)) {
                    etName.setError("name can't be empty ");
                    return;

                }
                if(etPhone.length()<10) {
                    etPhone.setError("phone number must be of 10 digits");
                    return;

                }
                fAuth.createUserWithEmailAndPassword(email , name).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()) {
                            Toast.makeText(adduserActivity.this,"user added",Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(),captchaverification.class));

                        }else {
                            Toast.makeText(adduserActivity.this, "error!"+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });

            }
        });


    }


   }
